import requests
import random
from bs4 import BeautifulSoup
import pandas as pd
import re
from dateutil import parser
from newspaper import Article
from newspaper import Config
from datetime import datetime
import datetime as dt
import nltk
from googlenewsdecoder import new_decoderv1
from time import sleep
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
# import base64


# Set dates for today and yesterday
now = dt.date.today()
now = now.strftime('%m-%d-%Y')
yesterday = dt.date.today() - dt.timedelta(days=1)
yesterday = yesterday.strftime('%m-%d-%Y')

# Setup requests configurations
nltk.download('punkt')

# header = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko)\
#                          Version/17.3.1 Safari/605.1.15'}

# Create a list of random user agents
user_agent_list = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko)\
                           Version/17.3.1 Safari/605.1.15',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:77.0) Gecko/20100101 Firefox/77.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_5) AppleWebKit/537.36 (KHTML, like Gecko)\
                           Chrome/83.0.4103.97 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:77.0) Gecko/20100101 Firefox/77.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)\
                           Chrome/83.0.4103.97 Safari/537.36'
]

config = Config()

for u_agent in user_agent_list:
    # Pick a random user agent
    user_agent = random.choice(user_agent_list)
# user_agent = ('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko)\
#                            Version/17.3.1 Safari/605.1.15')

    config.browser_user_agent = user_agent
    config.request_timeout = 20

    header = {'User-Agent': user_agent}

# Read in Alerts file and create empty lists for storing values
# read_file = pd.read_csv('EmergingRiskAlerts.csv')
read_file = pd.read_csv('EmergingRisksList.csv')

alert_name = []
title = []
published = []
link = []
domain = []
source = []
summary = []
key_words = []
sentiments = []
polarity = []

# Create or open dataframe file and create source df
try:
    alerts_df = pd.read_csv("EmergingRisks.csv", engine='python')
    alerts_df.PUBLISHED_DATE = pd.to_datetime(alerts_df.PUBLISHED_DATE)
except FileNotFoundError:
    alerts_df = pd.DataFrame(columns=['EMERGING_RISK_ID', 'alert_name', 'TITLE', 'SUMMARY', 'KEYWORDS', 'PUBLISHED_DATE', 'LINK',
                                      'SOURCE', 'SOURCE_URL', 'SENTIMENT', 'POLARITY'])

alerts_new_df = pd.DataFrame(columns=['EMERGING_RISK_ID', 'alert_name', 'TITLE', 'SUMMARY', 'KEYWORDS', 'PUBLISHED_DATE', 'LINK',
                                      'SOURCE', 'SOURCE_URL', 'SENTIMENT', 'POLARITY'])


source_df = pd.read_csv('sources.csv')
source_list = source_df.source_name.tolist()

print('Created dataframes')

url_start = 'https://news.google.com/rss/search?q={'
url_end = '}%20when%3A7d'  # Grabs search results over the days of the week


# Grab Google links
for i in read_file.search_terms:
    req = requests.get(url=url_start + i + url_end, headers=header)
    soup = BeautifulSoup(req.text, 'xml')
    q = 0
    for j in soup.findAll("title")[1:]:
        while q < (len(soup.findAll("source")[0:])):
            source_text = soup.findAll("source")[q].text
            title_text = soup.findAll("title")[q + 1].text
            if source_text in source_list:
                if title_text in title:
                    q += 1
                    break
                encoded_url = soup.find_all('link')[q].text
                interval_time = 5
                try:
                    decoded_url = new_decoderv1(encoded_url, interval=interval_time)
                    if decoded_url.get("status"):
                        title.extend([title_text])
                        alert_name.extend([i])
                        regex_pattern = re.compile('(https?):((|(\\\\))+[\w\d:#@%;$()~_?\+-=\\\.&]*)')
                        source_search = regex_pattern.search(str(soup.findAll("source")[q]))
                        domain.extend([source_search.group(0)])
                        source.extend([source_text])
                        pub_text = parser.parse(soup.findAll("pubDate")[q].text)
                        published.extend([pub_text.date()])
                        decoded_url = decoded_url['decoded_url']
                        link.append(decoded_url)
                    else:
                        print("Error:", decoded_url['message'])
                except Exception as e:
                    print(f"Error occurred: {e}")
                # for item in soup.find_all('item')[1:]:
                #     encoded_url = soup.find_all('link')[q].text
                #     # decoded_url = decoderv1(encoded_url)
                #     decoded_url = decoderv2(encoded_url)
                #     # decoded_url = decoderv3(encoded_url)
                #     # decoded_url = decoderv4(encoded_url)
                #     # for decoded_url in decoded_url_4:
                #     #     if decoded_url.get("status"):
                #     #         print("Decoded URL:", decoded_url["url"])
                #     #         full_url = decoded_url["url"]
                #     #     else:
                #     #         print("Error:", decoded_url)
                #     sleep(2)
                # for item in soup.find_all('item')[1:]:
                #     encoded_url = soup.find_all('guid')[q].text
                #     while not len(encoded_url) % 4 == 0:
                #         encoded_url += '='
                #     actual_url = base64.b64decode(encoded_url).decode('latin-1')
                #     actual_url_cleaned = actual_url[actual_url.find('https'):]
                #     actual_url_cleaned = actual_url_cleaned[:actual_url_cleaned.find('Ò')]
                # link.extend([full_url])
            q += 1

print('Created lists')

# Find article information
for article_link in link:
    article = Article(article_link, config=config)  # providing the link
    try:
        article.download()  # downloading the article
        article.parse()  # parsing the article
        article.nlp()  # performing natural language processing (nlp)
    except:
        pass
    summary.extend([article.summary])
    key_words.extend([article.keywords])
    analyzer = SentimentIntensityAnalyzer().polarity_scores(article.summary)
    neg = analyzer['neg']
    neu = analyzer['neu']
    pos = analyzer['pos']
    comp = analyzer['compound']
    if neg > pos or neg == -1:
        sentiments.extend(['negative'])
        polarity.extend(['-' + str(neg)])  # appending the news that satisfies this condition
    elif neg < pos:
        sentiments.extend(['positive'])
        polarity.extend(['+' + str(pos)])
    else:
        sentiments.extend(['neutral'])
        polarity.extend([str(neu)])

print('Length alert name: ', len(alert_name), ' Length Title: ', len(title), ' Length Link: ', len(link),
      ' Length KW: ', len(key_words))

alerts = pd.DataFrame(
    {'alert_name': alert_name,
     'TITLE': title,
     'PUBLISHED_DATE': published,
     'LINK': link,
     'SOURCE': source,
     'SOURCE_URL': domain,
     'SUMMARY': summary,
     'KEY_WORDS': key_words,
     'SENTIMENT': sentiments,
     'POLARITY': polarity
     })

print('Created sentiments')

joined_df = alerts.merge(read_file, on='alert_name', how='left')

new_alerts_df = pd.concat([alerts_new_df, joined_df], ignore_index=True)
new_alerts_df.PUBLISHED_DATE = pd.to_datetime(new_alerts_df.PUBLISHED_DATE)

alerts_df = pd.concat([alerts_df, joined_df], ignore_index=True)
alerts_df.PUBLISHED_DATE = pd.to_datetime(alerts_df.PUBLISHED_DATE)

final_new_df = new_alerts_df.sort_values(by='PUBLISHED_DATE', ascending=False)
final_new_df.PUBLISHED_DATE = final_new_df.PUBLISHED_DATE.apply(datetime.date)
final_new_df.to_csv('EmergingRisksNewGoogle.csv')

# final_df = alerts_df.sort_values(by='PUBLISHED_DATE', ascending=False)
# final_df.PUBLISHED_DATE = final_df.PUBLISHED_DATE.apply(datetime.date)
# final_df.to_csv('EmergingRisks.csv')

print('Created csv files')
