from setuptools import setup

setup(
    name='riskSurveillance',
    version='1.2',
    packages=[''],
    url='',
    license='',
    author='k33056',
    author_email='',
    description='Creates a curated list of articles on emerging risks.'
)
